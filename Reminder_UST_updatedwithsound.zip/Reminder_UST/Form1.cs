﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reminder_UST
{
    public partial class Form1 : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8VFNTLN\SQLEXPRESS;Initial Catalog=Reminder;Integrated Security=True");
       
         public Form1()
        {
            InitializeComponent();
        }

       //Reminder create

        private void button1_Click(object sender, EventArgs e)
        {
            //checking text box contain data or not, if not works this code
            if (richTextBox1.Text =="")
                 {

                MessageBox.Show("Add Some Content");
            }

                //if yes works this code
            else
            {
                DateTime dt = dateTimePicker1.Value;
                string var = richTextBox1.Text;

                //pick date and time from datepicker
                string s1 = dt.ToString("dd-MMMM-yyyy");
                string s2 = dt.ToString("h-mm-ss tt");

                //insert data
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into rtable (date,time,message) values('" + s1 + "','" + s2 + "','" + var + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Reminder Added Successfully");
                richTextBox1.Text = "";


                // update variables values
                DateTime now = DateTime.Now;
                current = now.ToString("dd/MMMM/yyyy");

                con.Open();
                SqlCommand cmd1 = con.CreateCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.CommandText = "select * from rtable where date='" + current + "'";
                SqlDataReader dr1 = cmd1.ExecuteReader();
                int i = 0;

                while (dr1.Read())
                {

                    t[i] = dr1["time"].ToString();
                    me[i] = dr1["message"].ToString();
                    i++;

                }

                con.Close();

            }


         }

        

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        //For Form2
        private void button2_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
        obj.Show();
         }

        //declares some arrays
        string current, time;
        string[] t=new string[5000];
        string[] me= new string[5000];

        //timer code
        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;

            //getting current time and display

            time = now.ToString("h/mm/ss tt");
            label3.Text = time.ToString();

            //checking current time with reminders time from database
           for (int i = 0; i < t.Length; i++)
            {
 
               //if a match found pop up that reminder
               if (time == t[i])
                {
                    //show reminder
                    axWindowsMediaPlayer1.URL = "C:\\Users\\SHERIN\\Downloads\\Camila Cabello   Havana.mp3";

                    MessageBox.Show(me[i]);
                    axWindowsMediaPlayer1.Ctlcontrols.stop();
                 }

            }

          }



        //Form load
        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            dateTimePicker1.MinDate = DateTime.Now.Date;
            DateTime now = DateTime.Now;
            
            
            current = now.ToString("dd/MMMM/yyyy");

            con.Open();
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "select * from rtable where date='" + current + "'";
            SqlDataReader dr1 = cmd1.ExecuteReader();
            int i = 0;

            while (dr1.Read())
            {

                t[i] = dr1["time"].ToString();
                me[i] = dr1["message"].ToString();
                i++;

            }

            con.Close();

           

        }

        //For form3
        private void button3_Click(object sender, EventArgs e)
        {
            Update obj = new Update();
            obj.Show();
        }

      

    }
}
