﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reminder_UST
{
    public partial class Update : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8VFNTLN\SQLEXPRESS;Initial Catalog=Reminder;Integrated Security=True");
       

        public Update()
        {
            InitializeComponent();
        }

        //declare some variables
        string s2, s1;
        int p = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible=false;
            DateTime dt = dateTimePicker1.Value;

            //pick date and time from datepicker
            s1 = dt.ToString("dd-MMMM-yyyy");
            s2= dt.ToString("h-mm-ss tt");
       

            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from rtable where date='" + s1 + "' and time='"+s2+"'  ";
            SqlDataReader dr = cmd.ExecuteReader();
           
            //values read

                while (dr.Read())
                {
                    if (dr["message"] != null)
                    {
                        richTextBox1.Visible = true;
                        button2.Visible = true;
                        richTextBox1.Text = dr["message"].ToString();
                        p = 1;
                    }

                 }

                con.Close();

                // if no values retrieve this code execute
            if (p != 1)
            {
                button2.Visible = false;
                richTextBox1.Visible = false;
                MessageBox.Show("Sry  , No reminders are added");
            }

            p = 0;

        }

        //code for update
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update  rtable set message='"+richTextBox1.Text+"' where date='" + s1 + "' and time='" + s2 + "'  ";
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Reminder Updated");
        }
    }
}
