﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reminder_UST
{
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8VFNTLN\SQLEXPRESS;Initial Catalog=Reminder;Integrated Security=True");
      

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           //create datetime object dt
            DateTime dt = dateTimePicker1.Value;


            //Declare come variables
            string s1 = dt.ToString("dd-MMMM-yyyy");
            int pointX = 125;
            int pointXZ = 145;
            int pointY = 100;
            int pointYZ = 130;
            int p = 0;

            //connection start and code for select
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from rtable where date='"+s1+"'";
            SqlDataReader dr = cmd.ExecuteReader();

            int i = 1;
            string v;

            // Values reads 
            while (dr.Read())
            {
                if (dr["message"] != null)
                {
                    //Creates Labels and Textboxs dynamically
                    // Label create and assign its property

                    Label a = new Label();
                    a.Text = dr["time"].ToString();
                    a.Location = new Point(pointX, pointY);
                    this.Controls.Add(a);
                    pointY += 100;

                    // Textbox create and assign its property
                    TextBox b = new TextBox();
                    v = "text" + (i).ToString();
                    b.Name = v;
                    b.Multiline = true;
                    b.Height = 40;
                    b.Width = 250;
                   
                    b.Text = dr["message"].ToString();
                    b.Location = new Point(pointXZ, pointYZ);
                    this.Controls.Add(b);
                    pointYZ += 100;
                    i++;
                    p = 1;

                    button1.Visible = false;
                    button2.Visible = true;
                    
                }
            }
       
            con.Close();

            // if no values retrieve this code execute
            if (p != 1)
            {
                button1.Visible = false;
                button2.Visible = true;
                MessageBox.Show("Sry  , No reminders are added");

                this.Controls.Clear();
                this.InitializeComponent();
                button1.Visible = false;

            }

            p = 0;

            
        }

        // code for Next Try button and clear everything

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            this.Controls.Clear();
            this.InitializeComponent();
            button2.Visible = false;
        }

        //Form load
        private void Form2_Load(object sender, EventArgs e)
        {
            button2.Visible = false;
        }
        
       
    }
}
